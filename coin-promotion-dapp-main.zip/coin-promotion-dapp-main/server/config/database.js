module.exports = {
  dialect: 'sqlite',
  storage: './server/data/database.sqlite',
};
